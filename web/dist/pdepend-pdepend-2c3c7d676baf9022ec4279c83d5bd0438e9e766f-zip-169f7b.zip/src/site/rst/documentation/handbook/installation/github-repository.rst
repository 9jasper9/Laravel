The GitHub Repository
~~~~~~~~~~~~~~~~~~~~~

**Note:** *This section is work in progress and not complete at the moment.*

.. include:: parts/github-abstract.rst

.. class:: prev

`Phar Archive`__

.. class:: next

`Command Line`__

__ /documentation/handbook/installation/phar-archive.html
__ /documentation/handbook/command-line.html
