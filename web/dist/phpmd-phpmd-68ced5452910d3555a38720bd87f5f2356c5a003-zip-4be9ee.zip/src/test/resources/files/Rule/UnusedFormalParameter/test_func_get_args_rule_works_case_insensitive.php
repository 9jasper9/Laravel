<?php
class test_func_get_args_rule_works_case_insensitive
{
    function test_func_get_args_rule_works_case_insensitive($foo, $bar, $baz)
    {
        return Func_Get_Args();
    }
}
