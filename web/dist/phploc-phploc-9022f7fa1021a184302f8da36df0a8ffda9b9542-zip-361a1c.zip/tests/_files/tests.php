<?php
class ATest extends PHPUnit_Framework_TestCase
{
    public function testFoo()
    {
    }

    /**
     * @test
     * @dataProvider barProvider
     */
    public function bar()
    {
    }

    protected function doSomething()
    {
    }

    public function barProvider()
    {
    }
}
