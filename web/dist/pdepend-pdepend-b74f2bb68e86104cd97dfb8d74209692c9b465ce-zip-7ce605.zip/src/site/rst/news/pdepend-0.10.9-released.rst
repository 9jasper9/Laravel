=======================
Version 0.10.8 released
=======================

:Author:       Manuel Pichler
:Copyright:    All rights reserved
:Description:  This release closes an issue in PHP_Depend's parser which results
               in a parsing exception when nowdoc was used as property or
               constant initializer.
:Keywords:     Release, Version, Bugfix, Parser, Release announcement

We are proud to announce that version `0.10.9`__ of PHP_Depend was released
on January the 25th 2012. This release fixes a small issue in PHP_Depend's
parser, which results in an exception when heredoc was used as property or
constant initializer.

Download
--------

Download the latest version of PHP_Depend as a `Phar archive`__ or through
PHP_Depend's `PEAR Channel Server`__.

__ /download/release/0.10.9/changelog.html
__ /download/release/0.10.9/pdepend.phar
__ http://pear.pdepend.org

