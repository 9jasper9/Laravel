<?php
function testRuleNotAppliesToFunctionWithoutExitExpression()
{
    echo __FUNCTION__;
}