<?php
class testRuleAppliesToLocalVariableInMethodWithNameLongerThanThreshold
{
    function testRuleAppliesToLocalVariableInMethodWithNameLongerThanThreshold()
    {
        $thisIsAReallyLongLocalVariable = 42;
    }
}