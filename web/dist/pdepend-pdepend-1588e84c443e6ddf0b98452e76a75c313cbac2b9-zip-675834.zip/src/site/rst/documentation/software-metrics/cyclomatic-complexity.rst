=====================
Cyclomatic Complexity
=====================

.. include:: parts/cyclomatic-complexity.rst
