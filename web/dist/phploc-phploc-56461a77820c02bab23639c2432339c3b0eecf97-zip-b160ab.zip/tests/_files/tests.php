<?php
class ATest extends PHPUnit_Framework_TestCase
{
    public function testFoo()
    {
    }

    protected function doSomething()
    {
    }
}
