===================================
Professional Support for PHP Depend
===================================

:Description:
  Some days ago I founded a company together with two good friends, Kore
  Nordmann and Tobias Schlitt, which will, beside other services, provide
  professional support around PHP Depend.

Some days ago I founded a company together with two good friends, Kore
Nordmann and Tobias Schlitt, which will, beside other services, provide
professional support around PHP Depend.

`Qafoo - passion for software quality`__ provides training and consulting
around high quality PHP software engineering and processes, you'll find more
information on this on our website__. Beside that Qafoo also provides
`professional support for quality assurance tools`__ like Arbit__, PHP_Depend,
and PhpUnderControl__.

So, if you are using PHP Depend in your company, we would be happy to discuss
support contracts with you. We designed plans for incident based and continuous
support, as you can see on our `support page`__.

__ http://qafoo.com/
__ http://qafoo.com/
__ http://qafoo.com/services/support.html
__ http://arbitracker.org/news.html
__ http://phpundercontrol.org/about.html
__ http://qafoo.com/services/support.html

