<?php
trait t
{
    public function m()
    {
    }
}
