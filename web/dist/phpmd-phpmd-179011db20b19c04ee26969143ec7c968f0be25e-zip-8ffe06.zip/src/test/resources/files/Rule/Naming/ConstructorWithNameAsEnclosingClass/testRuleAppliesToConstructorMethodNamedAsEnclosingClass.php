<?php
class testRuleAppliesToConstructorMethodNamedAsEnclosingClass
{
    function testRuleAppliesToConstructorMethodNamedAsEnclosingClass()
    {
        
    }
}