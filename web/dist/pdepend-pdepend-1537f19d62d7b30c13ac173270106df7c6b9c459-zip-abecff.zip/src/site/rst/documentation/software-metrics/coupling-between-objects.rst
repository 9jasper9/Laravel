==============================
CBO - Coupling Between Objects
==============================

.. include:: parts/coupling-between-objects.rst
