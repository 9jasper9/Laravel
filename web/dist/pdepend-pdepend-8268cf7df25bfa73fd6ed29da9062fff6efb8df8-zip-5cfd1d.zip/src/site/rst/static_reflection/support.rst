=================
Support & Contact
=================

If you think you found an error or you have an improvment for staticReflection,
you can send questions and suggestions to our mailinglist. Or if you are 
interested in helping to improve this software, by writing patches, extensions
or just providing new ideas, you should feel free to join staticReflection's 
`IRC channel`__ or send a message to the users@pdepend.org mailinglist.

__ irc://irc.euirc.net/#pdepend

Mailinglists
============

- commits@pdepend.org is the list to which automatically generated mails with
  information about repository checkins are sent.

  Sent an empty mail to commits-join@pdepend.org, to subscribe to this list.

- users@pdepend.org is the list where you will find help on staticReflection
  related topics.

  Sent an empty mail to users-join@pdepend.org, to subscribe to this list.

IRC
===

- You will always find help on staticReflection related topics in the 
  `#pdepend`__ channel on the `EuIRC`__ network.

__ irc://euirc.net/#pdepend
__ http://euirc.net

Issue-Tracker
=============

- You can file a ticket in staticReflection's `Issue tracker`__ when you think
  you found a bug or you have a feature request for staticReflection.

__ http://tracker.pdepend.org/static_reflection

