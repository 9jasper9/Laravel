<?php
function testRuleNotAppliesToLocalVariableInFunctionWithNameEqualToThreshold()
{
    $fooBar = 42;
}