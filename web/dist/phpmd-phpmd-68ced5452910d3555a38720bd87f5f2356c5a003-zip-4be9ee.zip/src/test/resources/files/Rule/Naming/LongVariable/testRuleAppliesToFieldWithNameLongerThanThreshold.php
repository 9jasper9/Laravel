<?php
class testRuleAppliesToFieldWithNameLongerThanThreshold
{
    protected $thisReallyLongClassFieldName = 42;
}