<?php
class testIsDeclarationReturnsFalseForInheritMethodDeclarationClass
    extends testIsDeclarationReturnsFalseForInheritMethodDeclarationParentClass
{
    public function testIsDeclarationReturnsFalseForInheritMethodDeclaration($foo)
    {

    }
}

class testIsDeclarationReturnsFalseForInheritMethodDeclarationParentClass
{
    public function testIsDeclarationReturnsFalseForInheritMethodDeclaration($foo)
    {

    }
}
