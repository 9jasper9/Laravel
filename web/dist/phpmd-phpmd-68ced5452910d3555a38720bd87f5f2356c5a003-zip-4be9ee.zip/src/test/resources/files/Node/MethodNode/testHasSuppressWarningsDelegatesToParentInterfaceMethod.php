<?php
/**
 * @SuppressWarnings("PHPMD.FooBar")
 */
interface testHasSuppressWarningsDelegatesToParentInterfaceMethodInterface
{
    function testHasSuppressWarningsDelegatesToParentInterfaceMethod();
}

/**
 * @SuppressWarnings("PHPMD.FooBar")
 */
interface testHasSuppressWarningsDelegatesToParentInterfaceMethodInterface
{
    function testHasSuppressWarningsDelegatesToParentInterfaceMethod();
}
