==============================
NPM - Number of Public Methods
==============================

.. include:: parts/number-of-public-methods.rst
