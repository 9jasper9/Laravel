======================
CE - Efferent Coupling
======================

.. include:: parts/efferent-coupling.rst
