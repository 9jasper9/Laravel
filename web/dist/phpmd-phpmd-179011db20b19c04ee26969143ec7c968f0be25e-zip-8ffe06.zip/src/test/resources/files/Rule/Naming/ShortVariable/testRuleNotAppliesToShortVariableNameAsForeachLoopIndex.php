<?php
function testRuleNotAppliesToShortVariableNameAsForeachLoopIndex()
{
    foreach ($array as $i => $value) {
        
    }
}