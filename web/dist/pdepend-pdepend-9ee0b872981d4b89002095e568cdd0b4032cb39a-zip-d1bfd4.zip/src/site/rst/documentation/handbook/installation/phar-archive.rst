The Phar Archive
~~~~~~~~~~~~~~~~

**Note:** *This section is work in progress and not complete at the moment.*

.. include:: parts/phar-abstract.rst

.. class:: prev

`Installation`__

.. class:: next

`GitHub Repository`__

__ /documentation/handbook/installation/index.rst
__ /documentation/handbook/installation/github-repository.html
