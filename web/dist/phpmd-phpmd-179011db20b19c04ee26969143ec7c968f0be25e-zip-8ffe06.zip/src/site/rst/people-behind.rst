===================
People behind PHPMD
===================

Contributors
============

- `Volker Dusch`__ / `https://github.com/edorian`__ /  (Since 2010)
- `timmartin`__ / `https://github.com/timmartin`__ /  (Since 2010)
- `Sebastian Bergmann`__ / `https://github.com/sebastianbergmann`__ / (Since 2011)
- `Zsolt Takacs`__ / `https://github.com/zstakacs`__ /  (Since 2011)
- `Che Hodgins`__ / `https://github.com/chehodgins`__ /  (Since 2011)
- `Gennadiy Litvinyuk`__ / `https://github.com/gennadiylitvinyuk`__ /  (Since 2011)
- `Francis Besset`__ / `https://github.com/francisbesset`__ /  (Since 2011)
- `zerkalica`__ / `https://github.com/zerkalica`__ /  (Since 2012)
- `palbertin`__ / `https://github.com/palbertini`__ /  (Since 2012)
- `bahulneel`__ / `https://github.com/bahulneel`__ /  (Since 2012)
- `Willem Stuursma`__ / `https://github.com/willemstuursma`__ /  (Since 2012)
- `Nimlhug`__ / `https://github.com/Nimlhug`__ /  (Since 2012)
- `A. Martin Llano`__ / `https://github.com/amllano`__ / (Since 2012)
- `Juan Basso`__ / `https://github.com/jrbasso`__ / (Since 2012)

__ https://github.com/edorian
__ https://github.com/edorian
__ https://github.com/timmartin
__ https://github.com/timmartin
__ https://github.com/sebastianbergmann
__ https://github.com/sebastianbergmann
__ https://github.com/zstakacs
__ https://github.com/zstakacs
__ https://github.com/chehodgins
__ https://github.com/chehodgins
__ https://github.com/gennadiylitvinyuk
__ https://github.com/gennadiylitvinyuk
__ https://github.com/francisbesset
__ https://github.com/francisbesset
__ https://github.com/zerkalica
__ https://github.com/zerkalica
__ https://github.com/palbertini
__ https://github.com/palbertini
__ https://github.com/bahulneel
__ https://github.com/bahulneel
__ https://github.com/willemstuursma
__ https://github.com/willemstuursma
__ https://github.com/Nimlhug
__ https://github.com/Nimlhug
__ https://github.com/amllano
__ https://github.com/amllano
__ https://github.com/jrbasso
__ https://github.com/jrbasso

Project founder
===============

- `Manuel Pichler`__ / `https://github.com/manuelpichler`__ / (Since 2009)

__ https://github.com/manuelpichler
__ https://github.com/manuelpichler


..
   Local Variables:
   mode: rst
   fill-column: 79
   End:
   vim: et syn=rst tw=79
