<?php
class testRuleAppliesToUnusedPrivateField
{
    private $foo = 0;
}
