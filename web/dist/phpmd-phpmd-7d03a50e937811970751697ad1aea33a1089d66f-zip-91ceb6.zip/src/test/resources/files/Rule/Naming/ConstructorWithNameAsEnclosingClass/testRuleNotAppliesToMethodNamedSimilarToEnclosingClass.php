<?php
class RuleNotAppliesToMethodNamedSimilarToEnclosingClass
{
    function testRuleNotAppliesToMethodNamedSimilarToEnclosingClass()
    {

    }
}