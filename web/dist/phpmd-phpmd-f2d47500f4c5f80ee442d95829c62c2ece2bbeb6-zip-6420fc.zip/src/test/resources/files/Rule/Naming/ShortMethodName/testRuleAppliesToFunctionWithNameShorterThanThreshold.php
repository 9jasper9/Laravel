<?php
function testRuleAppliesToFunctionWithNameShorterThanThreshold()
{

}