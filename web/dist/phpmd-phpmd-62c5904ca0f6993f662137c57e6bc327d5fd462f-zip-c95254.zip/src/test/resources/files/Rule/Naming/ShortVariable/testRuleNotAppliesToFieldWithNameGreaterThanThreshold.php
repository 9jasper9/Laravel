<?php
class testRuleNotAppliesToFieldWithNameGreaterThanThreshold
{
    private $foo = 42;
}