<?php
class testRuleAppliesToUnusedStaticPrivateMethod
{
    private static function foo()
    {
        
    }
}