Usage
~~~~~

.. include:: parts/usage.rst

.. class:: prev

`GitHub Repository`__

.. class:: next

`Reports`__

__ /documentation/handbook/installation/github-repository.html
__ /documentation/handbook/reports.html
