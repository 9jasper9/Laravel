<?php
class testRuleNotAppliesToVariablesFromExceptionsList
{
    private $id;

    public function setID($id)
    {
        $this->id = $id;
    }

}