==========================
CIS - Class Interface Size
==========================

.. include:: parts/class-interface-size.rst
