===========================
WMC - Weighted Method Count
===========================

.. include:: parts/weighted-method-count.rst
