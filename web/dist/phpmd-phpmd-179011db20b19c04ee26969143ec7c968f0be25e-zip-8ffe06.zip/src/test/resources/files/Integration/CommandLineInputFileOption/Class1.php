<?php
class Class1 {
    function foo()
    {
        $foo = 42;
    }
}