<?php
/**
 * @SuppressWarnings("PHPMD.FooBar")
 */
class testHasSuppressWarningsDelegatesToParentClassMethodClass
{
    public function testHasSuppressWarningsDelegatesToParentClassMethod() {}
}

/**
 * @SuppressWarnings("PHPMD.FooBar")
 */
class testHasSuppressWarningsDelegatesToParentClassMethodClass
{
    public function testHasSuppressWarningsDelegatesToParentClassMethod() {}
}
