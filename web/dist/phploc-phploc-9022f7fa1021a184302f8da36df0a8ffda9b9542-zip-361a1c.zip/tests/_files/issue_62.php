<?php
function fn()
{
    // CLOC
}
