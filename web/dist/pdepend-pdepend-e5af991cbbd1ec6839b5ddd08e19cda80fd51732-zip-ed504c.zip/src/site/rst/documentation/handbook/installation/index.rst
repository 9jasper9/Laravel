============
Installation
============

PEAR Installer
==============

.. include:: parts/pear-abstract.rst

`Read more`__

__ /documentation/handbook/installation/pear-installer.html

Phar Archive
============

.. include:: parts/phar-abstract.rst

GitHub Repository
=================

.. include:: parts/github-abstract.rst

.. class:: prev

`Introduction`__

.. class:: next

`PEAR Installer`__

__ /documentation/handbook/introduction.html
__ /documentation/handbook/installation/pear-installer.html
