<?php
class testRuleNotAppliesToLocalVariableInMethodWithNameEqualToThreshold
{
    function testRuleNotAppliesToLocalVariableInMethodWithNameEqualToThreshold()
    {
        $fooBar = 42;
    }
}