<?php
/**
 * @package ticket001
 */
class FooBarTicket001 {}