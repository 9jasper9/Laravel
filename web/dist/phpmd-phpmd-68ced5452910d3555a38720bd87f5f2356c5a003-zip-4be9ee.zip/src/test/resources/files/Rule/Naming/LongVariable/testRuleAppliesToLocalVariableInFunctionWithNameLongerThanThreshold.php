<?php
function testRuleAppliesToLocalVariableInFunctionWithNameLongerThanThreshold()
{
    $reallyLongVariableName = 42;
}