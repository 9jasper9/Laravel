<?php
// Nothing, no class :-) 
