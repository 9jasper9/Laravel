<?php
class testRuleNotAppliesForLongPrivateStaticProperty
{
    private static $testRuleNotAppliesForLongPrivateStaticProperty = 23;
}