If you like to participate on the social coding plattform `GitHub`__, you can
use `PHP_Depend's`__ GitHub mirror to fork and contribute to the project.

.. class:: shell

::

  ~ $ git clone git://github.com/manuelpichler/pdepend.git

__ http://github.com
__ http://github.com/manuelpichler/pdepend
