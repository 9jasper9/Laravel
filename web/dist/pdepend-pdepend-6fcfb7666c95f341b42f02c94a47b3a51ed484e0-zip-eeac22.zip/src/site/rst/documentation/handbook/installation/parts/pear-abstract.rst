The preferred way to install PHP Depend should be the `PEAR installer`__ and
PHP Depend's `PEAR channel`__, where you will always find the latest stable
version. Just enter: 

.. class:: shell

::

  ~ $ pear channel-discover pear.pdepend.org
  ~ $ pear install pdepend/PHP_Depend-beta

__ http://pear.php.net/manual/en/installation.php
__ http://pear.pdepend.org

