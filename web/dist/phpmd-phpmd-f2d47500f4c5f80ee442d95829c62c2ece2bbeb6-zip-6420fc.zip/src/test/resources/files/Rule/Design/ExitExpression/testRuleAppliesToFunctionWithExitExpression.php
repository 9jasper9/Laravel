<?php
function testRuleAppliesToFunctionWithExitExpression()
{
    exit(0);
}