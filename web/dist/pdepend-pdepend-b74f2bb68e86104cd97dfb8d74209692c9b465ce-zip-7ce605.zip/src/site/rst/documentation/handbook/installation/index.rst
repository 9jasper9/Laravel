============
Installation
============

Composer
========

.. include:: parts/composer-abstract.rst

Phar Archive
============

.. include:: parts/phar-abstract.rst

GitHub Repository
=================

.. include:: parts/github-abstract.rst

PEAR Installer
==============

.. include:: parts/pear-abstract.rst

`Read more`__

__ /documentation/handbook/installation/pear-installer.html

.. class:: prev

`Introduction`__

.. class:: next

`PEAR Installer`__

__ /documentation/handbook/introduction.html
__ /documentation/handbook/installation/pear-installer.html
