The PEAR Installer
~~~~~~~~~~~~~~~~~~

.. include:: parts/pear.rst

.. class:: prev

`Installation`__

.. class:: next

`Phar Archive`__

__ /documentation/handbook/installation.html
__ /documentation/handbook/installation/phar-archive.html
