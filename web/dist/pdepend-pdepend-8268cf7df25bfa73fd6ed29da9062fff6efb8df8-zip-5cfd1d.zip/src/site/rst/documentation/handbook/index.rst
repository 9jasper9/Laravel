===================
PHP_Depend Handbook
===================

- `Introduction`__
- `Installation`__

  - `PEAR Installer`__
  - `PHAR Archive`__
  - `GitHub Repository`__

- `Command-Line`__
- `Configuration`__
- `Reports`__

  - `Abstraction Instability Chart`__
  - `Overview Pyramid`__

__ /documentation/handbook/introduction.html
__ /documentation/handbook/installation.html
__ /documentation/handbook/installation/pear-installer.html
__ /documentation/handbook/installation/phar-archive.html
__ /documentation/handbook/installation/github-repository.html
__ /documentation/handbook/command-line.html
__ /documentation/handbook/configuration.html
__ /documentation/handbook/reports.html
__ /documentation/handbook/reports/abstraction-instability-chart.html
__ /documentation/handbook/reports/overview-pyramid.html
