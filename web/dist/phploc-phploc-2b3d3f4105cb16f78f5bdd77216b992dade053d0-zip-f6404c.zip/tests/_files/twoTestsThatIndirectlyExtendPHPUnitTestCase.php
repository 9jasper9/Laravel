<?php

class BaseTest extends PHPUnit_Framework_TestCase {
}

class AIndirectExtendTest extends BaseTest {
}

class BIndirectExtendTest extends BaseTest {
}

