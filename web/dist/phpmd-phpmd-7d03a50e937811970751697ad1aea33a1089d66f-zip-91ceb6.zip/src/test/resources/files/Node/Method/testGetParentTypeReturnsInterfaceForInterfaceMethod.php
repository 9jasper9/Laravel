<?php
interface testGetParentTypeReturnsInterfaceForInterfaceMethodInterface
{
    function testGetParentTypeReturnsInterfaceForInterfaceMethod();
}
interface testGetParentTypeReturnsInterfaceForInterfaceMethodInterface
{
    function testGetParentTypeReturnsInterfaceForInterfaceMethod();
}
