================
CSZ - Class Size
================

.. include:: parts/class-size.rst
