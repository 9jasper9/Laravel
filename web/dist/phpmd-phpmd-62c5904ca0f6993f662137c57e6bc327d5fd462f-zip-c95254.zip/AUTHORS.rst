================
Authors of PHPMD
================

Main Authors/Maintainers
------------------------

- Manuel Pichler (Since 2009)

Contributors
------------

- Volker Dusch (Since 2010) / https://github.com/edorian
- timmartin (Since 2010) / https://github.com/timmartin
- Sebastian Bergmann (Since 2011) / https://github.com/sebastianbergmann
- Zsolt Takacs (Since 2011) / https://github.com/zstakacs
- Che Hodgins (Since 2011) / https://github.com/chehodgins
- Gennadiy Litvinyuk (Since 2011) / https://github.com/gennadiylitvinyuk
- Francis Besset (Since 2011) / https://github.com/francisbesset


..
   Local Variables:
   mode: rst
   fill-column: 79
   End: 
   vim: et syn=rst tw=79
