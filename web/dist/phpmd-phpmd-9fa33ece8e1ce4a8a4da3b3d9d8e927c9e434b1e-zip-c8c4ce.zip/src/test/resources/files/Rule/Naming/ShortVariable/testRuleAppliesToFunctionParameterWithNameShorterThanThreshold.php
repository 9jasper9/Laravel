<?php
function testRuleAppliesToFunctionParameterWithNameShorterThanThreshold($x)
{

}