<?php
class testRuleAppliesToUnusedLocalVariable
{
    function testRuleAppliesToUnusedLocalVariable()
    {
        $x = 42;
    }
}