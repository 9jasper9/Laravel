The Phar Archive
~~~~~~~~~~~~~~~~

**Note:** *This section is work in progress and not complete at the moment.*

.. include:: parts/phar-abstract.rst

.. class:: prev

`PEAR Installer`__

.. class:: next

`GitHub Repository`__

__ /documentation/handbook/installation/pear-installer.html
__ /documentation/handbook/installation/github-repository.html
