DIT - Depth of Inheritance
~~~~~~~~~~~~~~~~~~~~~~~~~~

.. include:: parts/depth-of-inheritance.rst
