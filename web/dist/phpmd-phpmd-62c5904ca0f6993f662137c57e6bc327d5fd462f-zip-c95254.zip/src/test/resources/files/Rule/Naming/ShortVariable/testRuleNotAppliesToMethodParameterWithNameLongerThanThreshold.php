<?php
class testRuleNotAppliesToMethodParameterWithNameLongerThanThreshold
{
    function testRuleNotAppliesToMethodParameterWithNameLongerThanThreshold($foo) {}
}