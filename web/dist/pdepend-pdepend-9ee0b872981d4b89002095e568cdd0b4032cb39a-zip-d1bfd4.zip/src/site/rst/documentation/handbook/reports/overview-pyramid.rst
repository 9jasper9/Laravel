================
Overview Pyramid
================

.. include:: parts/overview-pyramid.rst

.. class:: prev

`Abstraction Instability Chart`__

.. class:: next

`Handbook`__

__ /documentation/handbook/reports/abstraction-instability-chart.html
__ /documentation/handbook.html
