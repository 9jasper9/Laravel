<?php
class testRuleSetInvokesRuleForClassInstance
{
    public $a, $b, $c, $d;
}