<?php
class testRuleDoesNotApplyToUnusedPublicField
{
    public $foo = 42;
}