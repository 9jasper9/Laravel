<?php
abstract class testRuleDoesNotApplyToAbstractMethodFormalParameter
{
    abstract function testRuleDoesNotApplyToAbstractMethodFormalParameter($x, $y, $z);
}