<?php
/**
 * @SuppressWarnings(PHPMD)
 */
class testApplyInvokesRuleWhenStrictModeIsSet
{
    
}
