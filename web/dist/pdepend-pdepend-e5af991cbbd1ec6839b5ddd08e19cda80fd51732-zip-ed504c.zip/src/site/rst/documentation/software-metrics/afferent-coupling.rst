======================
CA - Afferent Coupling
======================

.. include:: parts/afferent-coupling.rst
