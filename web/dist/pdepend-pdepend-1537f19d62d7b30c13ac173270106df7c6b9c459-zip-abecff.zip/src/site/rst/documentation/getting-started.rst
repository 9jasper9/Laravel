===============
Getting started
===============

This guide will give a short introduction howto install and use the PHP_Depend
software analyzer and metric tool.

Installation
============

.. include:: handbook/installation/parts/pear.rst

Usage
=====

.. include:: handbook/command-line/parts/usage.rst

