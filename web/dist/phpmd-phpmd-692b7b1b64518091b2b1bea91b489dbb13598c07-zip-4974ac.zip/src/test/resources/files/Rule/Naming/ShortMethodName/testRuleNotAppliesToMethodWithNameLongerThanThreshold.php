<?php
class testRuleNotAppliesToMethodWithNameLongerThanThreshold
{
    function testRuleNotAppliesToMethodWithNameLongerThanThreshold()
    {
        
    }
}