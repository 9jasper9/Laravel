<?php

class Foo
{
    public function testRuleAppliesToMethodWithElseExpression()
    {
        if (true) {
        } else {
        }
    }
}
