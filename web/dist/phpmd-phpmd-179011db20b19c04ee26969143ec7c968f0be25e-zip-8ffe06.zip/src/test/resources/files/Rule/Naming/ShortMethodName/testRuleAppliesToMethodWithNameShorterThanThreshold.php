<?php
class testRuleAppliesToMethodWithNameShorterThanThreshold
{
    function testRuleAppliesToMethodWithNameShorterThanThreshold()
    {
        
    }
}