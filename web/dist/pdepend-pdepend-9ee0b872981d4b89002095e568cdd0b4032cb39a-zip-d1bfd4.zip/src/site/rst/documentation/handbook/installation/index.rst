============
Installation
============

Composer
========

.. include:: parts/composer-abstract.rst

Phar Archive
============

.. include:: parts/phar-abstract.rst

GitHub Repository
=================

.. include:: parts/github-abstract.rst

.. class:: prev

`Introduction`__

.. class:: next

`Phar Installer`__

__ /documentation/handbook/introduction.html
__ /documentation/handbook/installation/phar-archive.html
